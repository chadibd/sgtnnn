'use strict';

const db                   = require('./db');
const { parseRequestAsync } = require('./useragent');
const bot                  = require('../bot');

/* ── Dedup cache: ip+path → last-seen timestamp ─────────────────── */
const RECENT   = new Map();
const DEDUP_MS = 60 * 1000; // ignore same ip+path within 60 s

function shouldCount(ip, urlPath) {
  const key = `${ip}|${urlPath}`;
  const now  = Date.now();
  const last = RECENT.get(key);
  if (last && now - last < DEDUP_MS) return false;
  RECENT.set(key, now);
  if (RECENT.size > 1000) {
    for (const [k, ts] of RECENT)
      if (now - ts > DEDUP_MS) RECENT.delete(k);
  }
  return true;
}

/* ── Skip list: static assets, API endpoints ─────────────────────── */
const SKIP_PREFIX = ['/css/', '/js/', '/uploads/', '/logo', '/favicon', '/public/'];
const SKIP_START  = ['/contact', '/upload/subjects'];

function isCountable(urlPath) {
  if (SKIP_START.some(p  => urlPath.startsWith(p)))  return false;
  if (SKIP_PREFIX.some(p => urlPath.startsWith(p)))  return false;
  if (/\.\w{1,5}$/.test(urlPath))                    return false; // file extension
  return true;
}

/* ── Attach live stats to every template (sync, never blocks) ───── */
function visitorMiddleware(req, res, next) {
  res.locals.siteStats = db.getStats();
  next();
}

/* ── Record a visit: persist + Discord log (fully async) ─────────── */
function recordVisit(req) {
  const urlPath = req.originalUrl.split('?')[0];
  if (!isCountable(urlPath)) return;

  // Resolve geo async, then log — never awaited by the caller
  parseRequestAsync(req).then(info => {
    if (!shouldCount(info.ip, urlPath)) return;

    db.recordVisit();

    const pageUrl = `${req.protocol}://${req.get('host')}${req.originalUrl}`;
    bot.logVisit({ pageUrl, ...info }).catch(() => {});
  }).catch(() => {});
}

module.exports = { visitorMiddleware, recordVisit };
