'use strict';

/* ================================================================
   BAC_TYPES
================================================================ */
const BAC_TYPES = [
  { value: 'commun',    label: 'Commun (tous)'               },
  { value: 'math',      label: 'Bac Mathématiques'           },
  { value: 'sciences',  label: 'Bac Sciences Expérimentales' },
  { value: 'eco',       label: 'Bac Économie et Gestion'     },
  { value: 'technique', label: 'Bac Technique'               },
  { value: 'lettres',   label: 'Bac Lettres'                 },
  { value: 'sport',     label: 'Bac Sport'                   },
  { value: 'info',      label: 'Bac Informatique'            },
];

/* ================================================================
   DOC_TYPES
================================================================ */
const DOC_TYPES = [
  { value: 'cours',     label: 'Course',    labelFr: 'Cours'     },
  { value: 'resume',    label: 'Summary',   labelFr: 'Résumé'    },
  { value: 'exercices', label: 'Exercises', labelFr: 'Exercices' },
];

function getDocTypes(lang) {
  return DOC_TYPES.map(d => ({ ...d, label: lang === 'fr' ? d.labelFr : d.label }));
}

/* ================================================================
   SUBJECTS
   Per the detailed spec:

   curriculum values:
     'common'   — identical syllabus for every listed section
     'shared'   — identical syllabus for a specific SUBSET (shared_with[])
     'specific' — exclusive syllabus for each section that has it

   bacs[] — all sections that teach this subject
   shared_with[] — peer sections sharing the SAME curriculum (when 'shared')
   group  — logical subject name, for dedup in upload form display

   !! IMPORTANT: "commun" in bacType on a document means it is useful
      for ALL sections (e.g. a document for the shared Anglais curriculum).
      Section-specific docs have their own bacType.
================================================================ */
const SUBJECTS = [

  /* ──────────────────────────────────────────────────────────────
     MATHÉMATIQUES — every section has its own exclusive programme
     ────────────────────────────────────────────────────────────── */
  { value: 'math_math',      label: 'Mathématiques', group: 'mathematiques',
    bacs: ['math'],      curriculum: 'specific' },
  { value: 'math_sci',       label: 'Mathématiques', group: 'mathematiques',
    bacs: ['sciences'],  curriculum: 'specific' },
  { value: 'math_eco',       label: 'Mathématiques', group: 'mathematiques',
    bacs: ['eco'],       curriculum: 'specific' },
  { value: 'math_tech',      label: 'Mathématiques', group: 'mathematiques',
    bacs: ['technique'], curriculum: 'specific' },
  { value: 'math_let',       label: 'Mathématiques', group: 'mathematiques',
    bacs: ['lettres'],   curriculum: 'specific' },
  { value: 'math_sport',     label: 'Mathématiques', group: 'mathematiques',
    bacs: ['sport'],     curriculum: 'specific' },
  { value: 'math_info',      label: 'Mathématiques', group: 'mathematiques',
    bacs: ['info'],      curriculum: 'specific' },

  /* ──────────────────────────────────────────────────────────────
     SCIENCES PHYSIQUES — specific per section
     ────────────────────────────────────────────────────────────── */
  { value: 'phys_math',      label: 'Sciences Physiques', group: 'sciences_physiques',
    bacs: ['math'],      curriculum: 'specific' },
  { value: 'phys_sci',       label: 'Sciences Physiques', group: 'sciences_physiques',
    bacs: ['sciences'],  curriculum: 'specific' },
  { value: 'phys_tech',      label: 'Sciences Physiques', group: 'sciences_physiques',
    bacs: ['technique'], curriculum: 'specific' },
  { value: 'phys_sport',     label: 'Sciences Physiques', group: 'sciences_physiques',
    bacs: ['sport'],     curriculum: 'specific' },
  { value: 'phys_info',      label: 'Sciences Physiques', group: 'sciences_physiques',
    bacs: ['info'],      curriculum: 'specific' },

  /* ──────────────────────────────────────────────────────────────
     SVT — specific per section
     ────────────────────────────────────────────────────────────── */
  { value: 'svt_math',       label: 'Sciences de la vie et de la terre', group: 'svt',
    bacs: ['math'],      curriculum: 'specific' },
  { value: 'svt_sci',        label: 'Sciences de la vie et de la terre', group: 'svt',
    bacs: ['sciences'],  curriculum: 'specific' },
  { value: 'svt_let',        label: 'Sciences de la vie et de la terre', group: 'svt',
    bacs: ['lettres'],   curriculum: 'specific' },
  { value: 'svt_sport',      label: 'Sciences de la vie et de la terre', group: 'svt',
    bacs: ['sport'],     curriculum: 'specific' },

  /* ──────────────────────────────────────────────────────────────
     INFORMATIQUE
     Shared curriculum: math + sciences + technique (same programme)
     All others have their own specific programme
     ────────────────────────────────────────────────────────────── */
  { value: 'info_shared',    label: 'Informatique', group: 'informatique',
    bacs: ['math','sciences','technique'],
    curriculum: 'shared', shared_with: ['math','sciences','technique'] },
  { value: 'info_eco',       label: 'Informatique', group: 'informatique',
    bacs: ['eco'],       curriculum: 'specific' },
  { value: 'info_let',       label: 'Informatique', group: 'informatique',
    bacs: ['lettres'],   curriculum: 'specific' },
  { value: 'info_sport',     label: 'Informatique', group: 'informatique',
    bacs: ['sport'],     curriculum: 'specific' },
  { value: 'info_info',      label: 'Algorithmes & STI', group: 'informatique',
    bacs: ['info'],      curriculum: 'specific' },

  /* ──────────────────────────────────────────────────────────────
     TECHNIQUE & MÉCANIQUE — exclusive to Bac Technique
     ────────────────────────────────────────────────────────────── */
  { value: 'tech_meca',      label: 'Technique & Mécanique',
    bacs: ['technique'], curriculum: 'specific' },

  /* ──────────────────────────────────────────────────────────────
     GESTION & ÉCONOMIE — exclusive to Bac Éco
     ────────────────────────────────────────────────────────────── */
  { value: 'gestion',        label: 'Gestion',
    bacs: ['eco'],       curriculum: 'specific' },
  { value: 'economie',       label: 'Économie',
    bacs: ['eco'],       curriculum: 'specific' },

  /* ──────────────────────────────────────────────────────────────
     HIST-GÉO — specific to eco & lettres (different programmes)
     ────────────────────────────────────────────────────────────── */
  { value: 'histgeo_eco',    label: 'Hist-Géo', group: 'hist_geo',
    bacs: ['eco'],       curriculum: 'specific' },
  { value: 'histgeo_let',    label: 'Hist-Géo', group: 'hist_geo',
    bacs: ['lettres'],   curriculum: 'specific' },

  /* ──────────────────────────────────────────────────────────────
     PENSÉE ISLAMIQUE — exclusive to Bac Lettres
     ────────────────────────────────────────────────────────────── */
  { value: 'pensee_islamique', label: 'Pensée Islamique',
    bacs: ['lettres'],   curriculum: 'specific' },

  /* ──────────────────────────────────────────────────────────────
     ANGLAIS
     Common: math, sciences, eco, technique, info
     Specific: lettres, sport (different programme)
     ────────────────────────────────────────────────────────────── */
  { value: 'anglais',        label: 'Anglais', group: 'anglais',
    bacs: ['math','sciences','eco','technique','info'],
    curriculum: 'common' },
  { value: 'anglais_let',    label: 'Anglais', group: 'anglais',
    bacs: ['lettres'],   curriculum: 'specific' },
  { value: 'anglais_sport',  label: 'Anglais', group: 'anglais',
    bacs: ['sport'],     curriculum: 'specific' },

  /* ──────────────────────────────────────────────────────────────
     ARABE
     Common: math, sciences, eco, technique, info
     Specific: lettres, sport
     ────────────────────────────────────────────────────────────── */
  { value: 'arabe',          label: 'Arabe', group: 'arabe',
    bacs: ['math','sciences','eco','technique','info'],
    curriculum: 'common' },
  { value: 'arabe_let',      label: 'Arabe', group: 'arabe',
    bacs: ['lettres'],   curriculum: 'specific' },
  { value: 'arabe_sport',    label: 'Arabe', group: 'arabe',
    bacs: ['sport'],     curriculum: 'specific' },

  /* ──────────────────────────────────────────────────────────────
     FRANÇAIS
     Common: math, sciences, eco, technique, info
     Specific: lettres, sport
     ────────────────────────────────────────────────────────────── */
  { value: 'francais',       label: 'Français', group: 'francais',
    bacs: ['math','sciences','eco','technique','info'],
    curriculum: 'common' },
  { value: 'francais_let',   label: 'Français', group: 'francais',
    bacs: ['lettres'],   curriculum: 'specific' },
  { value: 'francais_sport', label: 'Français', group: 'francais',
    bacs: ['sport'],     curriculum: 'specific' },

  /* ──────────────────────────────────────────────────────────────
     PHILOSOPHIE
     Common: math, sciences, eco, technique, info
     Specific: lettres, sport
     ────────────────────────────────────────────────────────────── */
  { value: 'philosophie',      label: 'Philosophie', group: 'philosophie',
    bacs: ['math','sciences','eco','technique','info'],
    curriculum: 'common' },
  { value: 'philosophie_let',  label: 'Philosophie', group: 'philosophie',
    bacs: ['lettres'],   curriculum: 'specific' },
  { value: 'philosophie_sport',label: 'Philosophie', group: 'philosophie',
    bacs: ['sport'],     curriculum: 'specific' },

  /* ──────────────────────────────────────────────────────────────
     ARTS & PLASTIQUES — common for most; NOT in sport
     ────────────────────────────────────────────────────────────── */
  { value: 'arts_plastiques', label: 'Arts & Plastiques',
    bacs: ['math','sciences','eco','technique','lettres','info'],
    curriculum: 'common' },

  /* ──────────────────────────────────────────────────────────────
     OPTIONAL / FOREIGN LANGUAGES — common across all sections
     ────────────────────────────────────────────────────────────── */
  { value: 'allemand',  label: 'Allemand',
    bacs: ['math','sciences','eco','technique','lettres','sport','info'], curriculum: 'common' },
  { value: 'espagnol',  label: 'Espagnol',
    bacs: ['math','sciences','eco','technique','lettres','sport','info'], curriculum: 'common' },
  { value: 'italien',   label: 'Italien',
    bacs: ['math','sciences','eco','technique','lettres','sport','info'], curriculum: 'common' },
  { value: 'russe',     label: 'Russe',
    bacs: ['math','sciences','eco','technique','lettres','sport','info'], curriculum: 'common' },
  { value: 'chinois',   label: 'Chinois',
    bacs: ['math','sciences','eco','technique','lettres','sport','info'], curriculum: 'common' },
  { value: 'turque',    label: 'Turque',
    bacs: ['math','sciences','eco','technique','lettres','sport','info'], curriculum: 'common' },
  { value: 'portugais', label: 'Portugais',
    bacs: ['math','sciences','eco','technique','lettres','sport','info'], curriculum: 'common' },
];

/* ================================================================
   Helpers
================================================================ */

/**
 * Upload form: all subjects for a given bac, de-duplicated by group
 * so "Mathématiques" appears once even though there are 7 entries.
 */
function getSubjectsForBac(bacType) {
  if (!bacType || bacType === 'commun') {
    // Return one entry per group
    const seen = new Set();
    return SUBJECTS.filter(s => {
      const key = s.group || s.value;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
  const raw  = SUBJECTS.filter(s => s.bacs.includes(bacType));
  const seen = new Set();
  return raw.filter(s => {
    const key = s.group || s.value;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

/**
 * Search filter: subjects visible for a given bac section.
 * Includes common-curriculum subjects (they apply to all).
 */
function getSearchSubjectsForBac(bacType) {
  if (!bacType || bacType === 'all' || bacType === 'commun') {
    const seen = new Set();
    return SUBJECTS.filter(s => {
      const key = s.group || s.value;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
  const raw  = SUBJECTS.filter(s => s.bacs.includes(bacType) || s.curriculum === 'common');
  const seen = new Set();
  return raw.filter(s => {
    const key = s.group || s.value;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

module.exports = {
  BAC_TYPES, DOC_TYPES, SUBJECTS,
  getDocTypes, getSubjectsForBac, getSearchSubjectsForBac,
};
