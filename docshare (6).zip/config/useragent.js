'use strict';

const http = require('http');

/* ================================================================
   UA Parser
================================================================ */
function parseUA(ua = '') {
  if (!ua) return { browser: 'Unknown', os: 'Unknown', device: 'Unknown' };

  let browser = 'Unknown';
  if      (/Edg\//i.test(ua))                                 browser = 'Edge';
  else if (/OPR\//i.test(ua))                                  browser = 'Opera';
  else if (/SamsungBrowser/i.test(ua))                         browser = 'Samsung Internet';
  else if (/YaBrowser/i.test(ua))                              browser = 'Yandex';
  else if (/UCBrowser/i.test(ua))                              browser = 'UC Browser';
  else if (/Chrome\/\d/i.test(ua) && !/Chromium/i.test(ua))   browser = 'Chrome';
  else if (/Chromium/i.test(ua))                               browser = 'Chromium';
  else if (/Firefox\/\d/i.test(ua))                            browser = 'Firefox';
  else if (/Safari\/\d/i.test(ua) && !/Chrome/i.test(ua))     browser = 'Safari';
  else if (/MSIE|Trident/i.test(ua))                           browser = 'Internet Explorer';

  let os = 'Unknown';
  if      (/Windows NT 10|Windows NT 11/i.test(ua)) os = 'Windows 10/11';
  else if (/Windows NT 6\.3/i.test(ua))              os = 'Windows 8.1';
  else if (/Windows NT 6\.2/i.test(ua))              os = 'Windows 8';
  else if (/Windows NT 6\.1/i.test(ua))              os = 'Windows 7';
  else if (/Windows/i.test(ua))                      os = 'Windows';
  else if (/iPhone OS ([\d_]+)/i.test(ua)) {
    const v = ua.match(/iPhone OS ([\d_]+)/i)?.[1]?.replace(/_/g, '.');
    os = `iOS ${v || ''}`.trim();
  }
  else if (/iPad/i.test(ua))                         os = 'iPadOS';
  else if (/Android ([\d.]+)/i.test(ua)) {
    const v = ua.match(/Android ([\d.]+)/i)?.[1] || '';
    os = `Android ${v}`.trim();
  }
  else if (/Mac OS X ([\d_]+)/i.test(ua)) {
    const v = ua.match(/Mac OS X ([\d_]+)/i)?.[1]?.replace(/_/g, '.');
    os = `macOS ${v || ''}`.trim();
  }
  else if (/Linux/i.test(ua))                        os = 'Linux';

  let device = 'Desktop';
  if      (/Mobi|Android|iPhone|iPod/i.test(ua)) device = 'Mobile';
  else if (/iPad|Tablet/i.test(ua))               device = 'Tablet';

  return { browser, os, device };
}

/* ================================================================
   IP normalisation
   ::1            → 127.0.0.1   (IPv6 loopback)
   ::ffff:x.x.x.x → x.x.x.x   (IPv4-mapped IPv6)
   real IPv6       → kept as-is
================================================================ */
function normalizeIP(raw = '') {
  const ip = (raw || '').trim();
  if (!ip)        return 'Unknown';
  if (ip === '::1') return '127.0.0.1';
  // IPv4-mapped IPv6 — two common formats
  const mapped4 = ip.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/i);
  if (mapped4) return mapped4[1];
  const mappedHex = ip.match(/^::ffff:([0-9a-f]{4}):([0-9a-f]{4})$/i);
  if (mappedHex) {
    // convert hex pairs to decimal octets
    const hi = parseInt(mappedHex[1], 16);
    const lo = parseInt(mappedHex[2], 16);
    return `${(hi >> 8) & 0xff}.${hi & 0xff}.${(lo >> 8) & 0xff}.${lo & 0xff}`;
  }
  return ip;
}

/* ================================================================
   IP validation — basic sanity check
================================================================ */
const IPV4_RE = /^(\d{1,3}\.){3}\d{1,3}$/;
const IPV6_RE = /^[0-9a-f:]+$/i;

function isValidPublicIP(ip) {
  if (!ip || ip === 'Unknown') return false;
  if (ip === '127.0.0.1')     return false;   // loopback
  if (IPV4_RE.test(ip)) {
    const parts = ip.split('.').map(Number);
    if (parts.some(p => p > 255)) return false;
    // Private ranges
    if (parts[0] === 10)  return false;
    if (parts[0] === 127) return false;
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return false;
    if (parts[0] === 192 && parts[1] === 168) return false;
    if (parts[0] === 169 && parts[1] === 254) return false; // link-local
    return true;
  }
  if (IPV6_RE.test(ip) && ip.includes(':')) {
    if (ip === '::1') return false;
    return true; // real IPv6
  }
  return false;
}

/* ================================================================
   Extract real client IP with full header priority chain
================================================================ */
function getClientIP(req) {
  // Priority: Cloudflare → standard proxy → real-ip → socket
  const candidates = [
    req.headers['cf-connecting-ip'],
    // X-Forwarded-For may contain multiple: take leftmost (real client)
    (req.headers['x-forwarded-for'] || '').split(',')[0],
    req.headers['x-real-ip'],
    req.headers['x-client-ip'],
    req.socket?.remoteAddress,
    req.ip,
  ];

  for (const raw of candidates) {
    if (!raw) continue;
    const normalized = normalizeIP(raw.trim());
    if (normalized && normalized !== 'Unknown') return normalized;
  }
  return 'Unknown';
}

/* ================================================================
   Geo lookup
   1. Cloudflare / Vercel / Nginx proxy headers (zero latency, 100% accurate)
   2. ip-api.com free API (45 req/min, no key needed)
   3. Graceful empty fallback — never blocks

   Cache: 1 hour per IP, dedup in-flight requests
================================================================ */
const GEO_CACHE   = new Map();
const GEO_PENDING = new Map();
const GEO_TTL     = 60 * 60 * 1000;  // 1 hour
const GEO_TIMEOUT = 4000;             // 4 s max

function getProxyGeo(req) {
  return {
    country: (req.headers['cf-ipcountry']           ||
              req.headers['x-country-code']          ||
              req.headers['x-vercel-ip-country']     || '').toUpperCase() || '',
    city:     req.headers['cf-ipcity']              ||
              req.headers['x-vercel-ip-city']        || '',
    region:   req.headers['cf-region']              ||
              req.headers['x-vercel-ip-country-region'] || '',
    isp:      '',
  };
}

function fetchGeo(ip) {
  // Never look up private / loopback IPs
  if (!isValidPublicIP(ip)) {
    return Promise.resolve({ city: 'Local', region: 'Local', country: 'LOCAL', isp: '', ts: Date.now() });
  }

  // Cache hit
  const cached = GEO_CACHE.get(ip);
  if (cached && Date.now() - cached.ts < GEO_TTL) return Promise.resolve(cached);

  // Dedup in-flight
  if (GEO_PENDING.has(ip)) return GEO_PENDING.get(ip);

  const promise = new Promise(resolve => {
    // Request country, regionName, city, isp, query (returns the IP back for verification)
    const url = `http://ip-api.com/json/${encodeURIComponent(ip)}?fields=status,message,country,regionName,city,isp,query`;

    const req = http.get(url, { timeout: GEO_TIMEOUT }, res => {
      let raw = '';
      res.on('data', c => { raw += c; });
      res.on('end', () => {
        try {
          const j = JSON.parse(raw);
          if (j.status === 'success') {
            const geo = {
              country: j.country    || '',
              region:  j.regionName || '',
              city:    j.city       || '',
              isp:     j.isp        || '',
              ts:      Date.now(),
            };
            GEO_CACHE.set(ip, geo);
            resolve(geo);
          } else {
            // ip-api returned fail (e.g. reserved range)
            resolve({ country: '', region: '', city: '', isp: '', ts: Date.now() });
          }
        } catch {
          resolve({ country: '', region: '', city: '', isp: '', ts: Date.now() });
        }
      });
    });

    req.on('error', ()  => resolve({ country: '', region: '', city: '', isp: '', ts: Date.now() }));
    req.on('timeout', () => { req.destroy(); resolve({ country: '', region: '', city: '', isp: '', ts: Date.now() }); });
  }).finally(() => GEO_PENDING.delete(ip));

  GEO_PENDING.set(ip, promise);
  return promise;
}

/* ================================================================
   Public API
================================================================ */

/** Synchronous — no geo (fast path, used where we fire-and-forget geo) */
function parseRequest(req) {
  const ua  = req.headers['user-agent'] || '';
  const { browser, os, device } = parseUA(ua);
  const ip         = getClientIP(req);
  const proxy      = getProxyGeo(req);
  const referer    = (req.headers['referer'] || req.headers['referrer'] || '').slice(0, 512);
  const acceptLang = (req.headers['accept-language'] || '').split(',')[0].trim();
  return { ip, browser, os, device, referer, acceptLang,
           country: proxy.country, city: proxy.city, region: proxy.region, isp: '' };
}

/** Async — always returns full geo, falling back to ip-api.com when proxy headers absent */
async function parseRequestAsync(req) {
  const base = parseRequest(req);
  if (base.country) return base;          // proxy header present — done
  const geo = await fetchGeo(base.ip);    // remote lookup
  return { ...base, ...geo };
}

module.exports = {
  parseUA, normalizeIP, isValidPublicIP,
  getClientIP, getProxyGeo, fetchGeo,
  parseRequest, parseRequestAsync,
};
