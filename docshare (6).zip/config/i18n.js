'use strict';

/* ================================================================
   DocShare TN — i18n
   Default: English. User can switch to French.
   Rules:
     - Subject names (Mathématiques, SVT…) → NEVER translated
     - Section names (Bac Math, Sciences…)  → NEVER translated
     - Document types (Cours/Résumé/Exercices) → translated
================================================================ */

const translations = {

  en: {
    /* ── Navigation ── */
    nav_home:       'Home',
    nav_explore:    'Explore',
    nav_bac:        'Baccalauréat',
    nav_contact:    'Contact',
    nav_share:      'Share',

    /* ── Hero ── */
    hero_eyebrow:   'Welcome to Student Gathering TN',
    hero_headline:  'Curated Courses, Series, and Books by Students for Students.',
    hero_upload:    'Upload a Resource',
    hero_explore:   'Explore Resources',

    /* ── Social proof ── */
    proof_reviews:  'reviews',

    /* ── Stats ── */
    stat_docs:      'Documents shared',
    stat_students:  'Students helped',
    stat_sections:  'Sections covered',
    stat_validated: 'Content validated',
    stat_visitors:  'Total visitors',
    stat_downloads: 'Total downloads',

    /* ── About ── */
    about_eyebrow:  'Modern Idea',
    about_heading:  'About Us',
    about_p1:       'Credit goes to Student Gathering TN for the resources used on this platform. You can explore our collection to download free courses, series, books, and more to support your academic journey.',
    about_p2:       'Student Gathering TN is a leading platform for Tunisian students to access free educational resources. This platform is designed to help students collaborate, share knowledge, and succeed in their studies.',
    discord_online: 'Members Online',
    discord_join:   'Join Discord',

    /* ── FAQ ── */
    faq_eyebrow:    'Frequently asked questions',
    faq_heading:    'FAQ',
    faq_q1:         'How do I share a document?',
    faq_a1:         'Click "Share", fill in the form with your name, Discord ID, document name, subject and file. A moderator will review it before publishing.',
    faq_q2:         'Are documents verified?',
    faq_a2:         'Yes! Every submission is sent to Discord. A moderator clicks Accept or Deny — only accepted documents appear on the site.',
    faq_q3:         'Is it free?',
    faq_a3:         'Completely free — both sharing and downloading. No account required to browse documents.',
    faq_q4:         'What file types are accepted?',
    faq_a4:         'PDF, Word (.doc/.docx), PowerPoint, Excel, images (JPG, PNG, GIF, WebP) and ZIP — up to 50 MB per file.',

    /* ── Contact ── */
    contact_card_title:  'Contact Menu',
    contact_name:        'Your Name',
    contact_email:       'your@email.com',
    contact_message:     'Your message…',
    contact_submit:      'Submit',
    contact_eyebrow:     'Get in Touch',
    contact_heading:     'Contact Us',
    contact_address:     'Sfax/Bizerte/Nabeul, Tunisia',
    contact_follow:      'Follow Us',
    contact_copy:        'Developed by _gx_',
    form_ok:             '✅ Message sent! We\'ll get back to you soon.',
    form_err_fields:     '⚠️ All fields are required.',
    form_err_send:       '⚠️ Could not send. Please try again.',

    /* ── Upload page ── */
    upload_eyebrow:      'Share',
    upload_title:        'Share a Document',
    upload_subtitle:     'Course, summary or exercises — published after Discord validation.',
    upload_your_name:    'Your name',
    upload_name_ph:      'e.g. Ahmed Benali',
    upload_name_hint:    'Displayed on the document page.',
    upload_discord_id:   'Discord ID',
    upload_discord_hint: 'Settings → Advanced → Developer Mode → Right-click your username.',
    upload_doc_name:     'Document name',
    upload_doc_name_ph:  'e.g. Mathematics Course — Functions — Bac Math',
    upload_doc_type:     'Document type',
    upload_bac_type:     'Section / Bac',
    upload_subject:      'Subject',
    upload_subject_ph:   '— Select a section first —',
    upload_subject_hint: 'List updates based on the chosen section.',
    upload_file:         'File',
    upload_drop_label:   'Drop your file here or click',
    upload_drop_hint:    'PDF, Word, PPT, Excel, Images, ZIP — max 50 MB',
    upload_legal:        '🔒 By submitting, you confirm you are the author or have distribution rights. Every document is reviewed before publication.',
    upload_submit:       'Submit for review',
    upload_info_valid:   'Fast validation',
    upload_info_valid_d: 'Reviewed within 24h.',
    upload_info_link:    'Unique link',
    upload_info_link_d:  'Permanent URL.',
    upload_info_free:    '100% Free',
    upload_info_free_d:  'No sign-up needed.',
    upload_err_fix:      'Please fix the following errors:',

    /* ── Upload success ── */
    suc_eyebrow:    'Submitted!',
    suc_title:      'Document submitted!',
    suc_subtitle:   'Awaiting validation — note your ID to track it.',
    suc_name:       'Name',
    suc_id:         'Unique ID',
    suc_section:    'Section',
    suc_subject:    'Subject',
    suc_type:       'Type',
    suc_status:     'Status',
    suc_pending:    '⏳ Pending',
    suc_steps_hd:   'Next steps',
    suc_step1:      'A moderator receives a Discord notification and reviews your document.',
    suc_step2:      'If accepted, it will be published and accessible via its unique link.',
    suc_step3:      'Note your ID:',
    suc_another:    'Submit another',
    suc_explore:    'Explore',

    /* ── Search page ── */
    srch_eyebrow:   'Explore',
    srch_title:     'Search Documents',
    srch_subtitle:  'Courses, summaries and exercises validated for all bacs.',
    srch_ph:        'Search by name, subject or author…',
    srch_btn:       'Search',
    srch_all_sec:   'All sections',
    srch_all_sub:   'All subjects',
    srch_all_type:  'All types',
    srch_clear:     'Clear',
    srch_none:      'No documents found.',
    srch_none_sub:  'Try different terms or',
    srch_none_link: 'share a document',
    srch_found_one: 'document found',
    srch_found_pl:  'documents found',
    filt_section:   'Section',
    filt_subject:   'Subject',
    filt_type:      'Type',

    /* ── Document page ── */
    doc_published:  'Published by',
    doc_downloads:  'Downloads',
    doc_date:       'Date',
    doc_file:       'File',
    doc_back:       'Back to search',
    doc_download:   'Download document',
    doc_loading:    '⏳ Downloading…',
    doc_share:      'Share this document',
    doc_copy_link:  'Copy link',
    doc_no_preview: 'Preview not available for this file type.',

    /* ── 404 ── */
    e404_eyebrow:   'Oops',
    e404_title:     'Page not found',
    e404_body:      'The page or document you\'re looking for doesn\'t exist or has been removed.',
    e404_search:    'Browse documents',
    e404_share:     'Share',

    /* ── Footer ── */
    footer_copy:    'All rights reserved',
    sticky_msg:     '📚 Notes to share?',
    sticky_strong:  'Help your classmates!',
    sticky_btn:     'Share now',

    /* ── Discord popup ── */
    dp_sub:    'Discord Community',
    dp_msgs: [
      '🎓 Join our Discord for study sessions, exclusive resources and peer support!',
      '📚 300+ members online on our Discord. Share your notes and grow together!',
      '🌙 Studying late? We\'re here! Join us on Discord for lofi study sessions.',
      '✨ Questions about the bac? Ask on our Discord — the community replies fast!',
      '🚀 Join the students who succeed! Our Discord is the hub for Tunisian students.',
    ],
    dp_join:    'Join Discord',
    dp_later:   'Later',

    /* ── Document types (TRANSLATED) ── */
    dtype_cours:     'Course',
    dtype_resume:    'Summary',
    dtype_exercices: 'Exercises',
  },

  fr: {
    /* ── Navigation ── */
    nav_home:       'Accueil',
    nav_explore:    'Explorer',
    nav_bac:        'Baccalauréat',
    nav_contact:    'Contact',
    nav_share:      'Partager',

    /* ── Hero ── */
    hero_eyebrow:   'Bienvenue sur Student Gathering TN',
    hero_headline:  'Cours, Résumés et Exercices par les Élèves pour les Élèves.',
    hero_upload:    'Partager une ressource',
    hero_explore:   'Explorer les ressources',

    /* ── Social proof ── */
    proof_reviews:  'avis',

    /* ── Stats ── */
    stat_docs:      'Documents partagés',
    stat_students:  'Élèves aidés',
    stat_sections:  'Sections couvertes',
    stat_validated: 'Contenus validés',
    stat_visitors:  'Visiteurs totaux',
    stat_downloads: 'Téléchargements totaux',

    /* ── About ── */
    about_eyebrow:  'Idée Moderne',
    about_heading:  'À propos',
    about_p1:       'Toute la reconnaissance revient à Student Gathering TN pour les ressources de cette plateforme. Explorez notre collection pour télécharger gratuitement des cours, résumés, exercices et plus encore.',
    about_p2:       'Student Gathering TN est la plateforme de référence pour les élèves tunisiens. Elle est conçue pour faciliter la collaboration, le partage de connaissances et la réussite au baccalauréat.',
    discord_online: 'Membres en ligne',
    discord_join:   'Rejoindre Discord',

    /* ── FAQ ── */
    faq_eyebrow:    'Questions fréquentes',
    faq_heading:    'FAQ',
    faq_q1:         'Comment partager un document ?',
    faq_a1:         'Cliquez sur "Partager", remplissez le formulaire avec votre nom, ID Discord, le nom du document, la matière et le fichier. Un modérateur le vérifiera avant publication.',
    faq_q2:         'Les documents sont-ils vérifiés ?',
    faq_a2:         'Oui ! Chaque soumission est envoyée sur Discord. Un modérateur clique Accept ou Deny — seuls les documents acceptés apparaissent sur le site.',
    faq_q3:         'C\'est gratuit ?',
    faq_a3:         'Totalement gratuit — partage et téléchargement. Aucune inscription requise pour consulter les documents.',
    faq_q4:         'Quels types de fichiers sont acceptés ?',
    faq_a4:         'PDF, Word (.doc/.docx), PowerPoint, Excel, images (JPG, PNG, GIF, WebP) et ZIP — jusqu\'à 50 Mo par fichier.',

    /* ── Contact ── */
    contact_card_title:  'Menu de Contact',
    contact_name:        'Votre Nom',
    contact_email:       'votre@email.com',
    contact_message:     'Votre message…',
    contact_submit:      'Envoyer',
    contact_eyebrow:     'Nous Contacter',
    contact_heading:     'Contact Us',
    contact_address:     'Sfax/Bizerte/Nabeul, Tunisie',
    contact_follow:      'Suivez-nous',
    contact_copy:        'Développé par _gx_',
    form_ok:             '✅ Message envoyé ! Nous vous répondrons bientôt.',
    form_err_fields:     '⚠️ Tous les champs sont requis.',
    form_err_send:       '⚠️ Impossible d\'envoyer. Réessayez.',

    /* ── Upload page ── */
    upload_eyebrow:      'Partager',
    upload_title:        'Partager un Document',
    upload_subtitle:     'Cours, résumé ou exercice — publié après validation Discord.',
    upload_your_name:    'Votre nom',
    upload_name_ph:      'Ex : Ahmed Benali',
    upload_name_hint:    'Affiché sur la fiche du document.',
    upload_discord_id:   'ID Discord',
    upload_discord_hint: 'Paramètres → Avancé → Mode développeur → Clic droit sur votre pseudo.',
    upload_doc_name:     'Nom du document',
    upload_doc_name_ph:  'Ex : Cours Mathématiques — Fonctions — Bac Math',
    upload_doc_type:     'Type de document',
    upload_bac_type:     'Section / Bac',
    upload_subject:      'Matière',
    upload_subject_ph:   '— Sélectionnez d\'abord une section —',
    upload_subject_hint: 'La liste se met à jour selon la section choisie.',
    upload_file:         'Fichier',
    upload_drop_label:   'Glissez le fichier ici ou cliquez',
    upload_drop_hint:    'PDF, Word, PPT, Excel, Images, ZIP — max 50 Mo',
    upload_legal:        '🔒 En soumettant, vous confirmez être l\'auteur ou disposer des droits. Chaque document est validé avant publication.',
    upload_submit:       'Soumettre pour validation',
    upload_info_valid:   'Validation rapide',
    upload_info_valid_d: 'Examiné sous 24h.',
    upload_info_link:    'Lien unique',
    upload_info_link_d:  'URL permanente.',
    upload_info_free:    '100% Gratuit',
    upload_info_free_d:  'Sans inscription.',
    upload_err_fix:      'Veuillez corriger les erreurs suivantes :',

    /* ── Upload success ── */
    suc_eyebrow:    'Soumis !',
    suc_title:      'Document soumis !',
    suc_subtitle:   'En attente de validation — notez votre ID pour le suivre.',
    suc_name:       'Nom',
    suc_id:         'ID unique',
    suc_section:    'Section',
    suc_subject:    'Matière',
    suc_type:       'Type',
    suc_status:     'Statut',
    suc_pending:    '⏳ En attente',
    suc_steps_hd:   'Prochaines étapes',
    suc_step1:      'Un modérateur reçoit une notification Discord et examine votre document.',
    suc_step2:      'S\'il est accepté, il sera publié et accessible via son lien unique.',
    suc_step3:      'Notez votre ID :',
    suc_another:    'Soumettre un autre',
    suc_explore:    'Explorer',

    /* ── Search page ── */
    srch_eyebrow:   'Explorer',
    srch_title:     'Rechercher des Documents',
    srch_subtitle:  'Cours, résumés et exercices validés pour tous les bacs.',
    srch_ph:        'Rechercher par nom, matière ou auteur…',
    srch_btn:       'Rechercher',
    srch_all_sec:   'Toutes sections',
    srch_all_sub:   'Toutes matières',
    srch_all_type:  'Tous types',
    srch_clear:     'Effacer',
    srch_none:      'Aucun document trouvé.',
    srch_none_sub:  'Essayez d\'autres termes ou',
    srch_none_link: 'partagez un document',
    srch_found_one: 'document trouvé',
    srch_found_pl:  'documents trouvés',
    filt_section:   'Section',
    filt_subject:   'Matière',
    filt_type:      'Type',

    /* ── Document page ── */
    doc_published:  'Publié par',
    doc_downloads:  'Téléchargements',
    doc_date:       'Date',
    doc_file:       'Fichier',
    doc_back:       'Retour à la recherche',
    doc_download:   'Télécharger le document',
    doc_loading:    '⏳ Téléchargement…',
    doc_share:      'Partager ce document',
    doc_copy_link:  'Copier le lien',
    doc_no_preview: 'Aperçu non disponible pour ce type de fichier.',

    /* ── 404 ── */
    e404_eyebrow:   'Oops',
    e404_title:     'Page introuvable',
    e404_body:      'La page ou le document que vous cherchez n\'existe pas ou a été supprimé.',
    e404_search:    'Parcourir les documents',
    e404_share:     'Partager',

    /* ── Footer ── */
    footer_copy:    'Tous droits réservés',
    sticky_msg:     '📚 Des notes à partager ?',
    sticky_strong:  'Aide tes camarades !',
    sticky_btn:     'Partager maintenant',

    /* ── Discord popup ── */
    dp_sub:    'Communauté Discord',
    dp_msgs: [
      '🎓 Rejoins notre Discord pour des study sessions, des ressources exclusives et l\'entraide entre élèves !',
      '📚 Plus de 300 membres en ligne sur notre Discord. Partage tes notes et progresse avec la communauté !',
      '🌙 Tu révises tard ? On est là ! Rejoins-nous sur Discord pour des sessions lofi study.',
      '✨ Des questions sur le bac ? Pose-les sur notre Discord — la communauté répond en quelques minutes !',
      '🚀 Rejoins les élèves qui réussissent ! Notre Discord est le QG des futurs bacheliers tunisiens.',
    ],
    dp_join:    'Rejoindre Discord',
    dp_later:   'Plus tard',

    /* ── Document types (TRANSLATED) ── */
    dtype_cours:     'Cours',
    dtype_resume:    'Résumé',
    dtype_exercices: 'Exercices',
  },
};

/**
 * Get the translation object for a given locale.
 * Falls back to English for any missing keys.
 */
function getT(locale) {
  const lang = (locale === 'fr') ? 'fr' : 'en';
  const base = translations.en;
  const over = translations[lang];
  return new Proxy(over, {
    get(target, key) {
      return key in target ? target[key] : base[key];
    }
  });
}

/**
 * Express middleware — reads ?lang= or cookie, sets res.locals.t and res.locals.lang
 */
function i18nMiddleware(req, res, next) {
  // Priority: query param → cookie → default English
  let lang = req.query.lang || req.cookies?.lang || 'en';
  if (lang !== 'fr') lang = 'en';

  // Persist choice in cookie (1 year)
  if (req.query.lang) {
    res.cookie('lang', lang, { maxAge: 365 * 24 * 3600 * 1000, httpOnly: false, sameSite: 'lax' });
  }

  res.locals.t    = getT(lang);
  res.locals.lang = lang;
  next();
}

module.exports = { getT, i18nMiddleware, translations };
