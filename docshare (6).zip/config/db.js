'use strict';

const fs   = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'db.json');

function ensureDb() {
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify(
      { documents: [], stats: { totalVisits: 0, totalDownloads: 0 } }, null, 2
    ));
  }
}

function read() {
  ensureDb();
  try {
    const raw = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    if (!raw.stats) raw.stats = { totalVisits: 0, totalDownloads: 0 };
    return raw;
  } catch {
    return { documents: [], stats: { totalVisits: 0, totalDownloads: 0 } };
  }
}

function write(data) {
  ensureDb();
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function increment(field) {
  const data = read();
  data.stats[field] = (data.stats[field] || 0) + 1;
  write(data);
  return data.stats[field];
}

const db = {
  getAllDocuments()  { return read().documents; },
  getDocument(id)   { return read().documents.find(d => d.id === id) || null; },

  addDocument(doc) {
    const data = read();
    data.documents.push(doc);
    write(data);
    return doc;
  },

  updateDocument(id, updates) {
    const data = read();
    const idx  = data.documents.findIndex(d => d.id === id);
    if (idx === -1) return null;
    data.documents[idx] = { ...data.documents[idx], ...updates };
    write(data);
    return data.documents[idx];
  },

  deleteDocument(id) {
    const data = read();
    const idx  = data.documents.findIndex(d => d.id === id);
    if (idx === -1) return false;
    data.documents.splice(idx, 1);
    write(data);
    return true;
  },

  recordVisit()    { return increment('totalVisits');    },
  recordDownload() { return increment('totalDownloads'); },

  recordDocDownload(id) {
    const data = read();
    const idx  = data.documents.findIndex(d => d.id === id);
    if (idx !== -1) {
      data.documents[idx].downloads = (data.documents[idx].downloads || 0) + 1;
      data.stats.totalDownloads     = (data.stats.totalDownloads     || 0) + 1;
      write(data);
      return data.documents[idx].downloads;
    }
    return 0;
  },

  getStats() {
    const data = read();
    const docs = data.documents;
    return {
      totalVisits:    data.stats.totalVisits    || 0,
      totalDownloads: data.stats.totalDownloads || 0,
      totalDocs:      docs.filter(d => d.status === 'approved').length,
      totalPending:   docs.filter(d => d.status === 'pending').length,
    };
  },

  /**
   * Search with "commun" inclusion:
   * A document with bacType='commun' appears in every section's results.
   * Subject matching uses the subject value stored on the document.
   */
  searchDocuments({ query, bacType, subject, docType } = {}) {
    let docs = read().documents.filter(d => d.status === 'approved');

    if (query && query.trim()) {
      const q = query.trim().toLowerCase();
      docs = docs.filter(d =>
        d.name.toLowerCase().includes(q)          ||
        (d.subjectLabel || d.subject || '').toLowerCase().includes(q) ||
        d.publisherName.toLowerCase().includes(q)
      );
    }

    if (bacType && bacType !== 'all') {
      // Show docs for this section AND commun docs
      docs = docs.filter(d => d.bacType === bacType || d.bacType === 'commun');
    }

    if (subject && subject !== 'all') {
      // Match on both value and group
      const { SUBJECTS } = require('./constants');
      const subj = SUBJECTS.find(s => s.value === subject);
      const group = subj ? (subj.group || subj.value) : subject;
      docs = docs.filter(d => {
        const ds = SUBJECTS.find(s => s.value === d.subject);
        const dg = ds ? (ds.group || ds.value) : d.subject;
        return dg === group || d.subject === subject;
      });
    }

    if (docType && docType !== 'all') {
      docs = docs.filter(d => d.docType === docType);
    }

    return docs;
  },
};

module.exports = db;
