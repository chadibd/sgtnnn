'use strict';

require('dotenv').config();
const {
  Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, EmbedBuilder, SlashCommandBuilder, REST, Routes, Events
} = require('discord.js');
const db   = require('./config/db');
const path = require('path');
const fs   = require('fs');

const TOKEN           = process.env.DISCORD_BOT_TOKEN;
const REVIEW_CHANNEL  = process.env.REVIEW_CHANNEL_ID;
const LOG_CHANNEL     = process.env.LOG_CHANNEL_ID;
const CONTACT_CHANNEL = process.env.CONTACT_CHANNEL_ID;
const OWNER_ROLE_ID   = process.env.OWNER_ROLE_ID;
const DOMAIN          = process.env.DOMAIN || 'http://localhost:3000';

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages]
});

// ── Slash commands ─────────────────────────────────────────────
const commands = [
  new SlashCommandBuilder()
    .setName('deletedoc')
    .setDescription('Delete a document by ID (owner only)')
    .addStringOption(o => o.setName('id').setDescription('Document ID').setRequired(true))
    .toJSON(),
];

async function registerCommands(guildId) {
  const rest = new REST({ version: '10' }).setToken(TOKEN);
  try {
    await rest.put(Routes.applicationGuildCommands(client.user.id, guildId), { body: commands });
  } catch (e) { console.error('[Bot] Commands:', e.message); }
}

client.once(Events.ClientReady, async c => {
  console.log(`[Bot] ${c.user.tag}`);
  for (const [id] of c.guilds.cache) await registerCommands(id);
});

// ── Interactions ───────────────────────────────────────────────
client.on(Events.InteractionCreate, async interaction => {

  if (interaction.isButton()) {
    const [action, docId] = interaction.customId.split('__');
    if (!['accept','deny'].includes(action)) return;

    const doc = db.getDocument(docId);
    if (!doc)                     return interaction.reply({ content: '❌ Not found.',           ephemeral: true });
    if (doc.status !== 'pending') return interaction.reply({ content: `⚠️ Already ${doc.status}.`, ephemeral: true });

    const status = action === 'accept' ? 'approved' : 'denied';
    db.updateDocument(docId, { status, reviewedBy: interaction.user.tag, reviewedAt: new Date().toISOString() });

    const embed = EmbedBuilder.from(interaction.message.embeds[0])
      .setColor(status === 'approved' ? 0x22c55e : 0xef4444)
      .setFooter({ text: `${status.toUpperCase()} by ${interaction.user.tag} • ${new Date().toLocaleString()}` });

    await interaction.update({
      embeds: [embed],
      components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('n1').setLabel('✅ Accept').setStyle(ButtonStyle.Success).setDisabled(true),
        new ButtonBuilder().setCustomId('n2').setLabel('❌ Deny').setStyle(ButtonStyle.Danger).setDisabled(true),
      )],
    });

    if (status === 'approved') {
      const ch = await client.channels.fetch(LOG_CHANNEL).catch(() => null);
      if (ch) ch.send(`✅ **Published:** ${doc.name} — ${DOMAIN}/document/${docId}`);
    }
    return;
  }

  if (interaction.isChatInputCommand() && interaction.commandName === 'deletedoc') {
    if (!interaction.member.roles.cache.has(OWNER_ROLE_ID))
      return interaction.reply({ content: '🚫 No permission.', ephemeral: true });

    const id  = interaction.options.getString('id');
    const doc = db.getDocument(id);
    if (!doc) return interaction.reply({ content: `❌ No doc \`${id}\`.`, ephemeral: true });

    if (doc.filePath) {
      const f = path.join(__dirname, 'public', 'uploads', path.basename(doc.filePath));
      if (fs.existsSync(f)) fs.unlinkSync(f);
    }
    db.deleteDocument(id);
    return interaction.reply({ content: `🗑️ **${doc.name}** deleted.`, ephemeral: true });
  }
});

// ── sendContactMessage ─────────────────────────────────────────
async function sendContactMessage({ name, email, message }) {
  if (!CONTACT_CHANNEL || CONTACT_CHANNEL === 'your_contact_channel_id') return;
  const ch = await client.channels.fetch(CONTACT_CHANNEL);
  await ch.send({ embeds: [new EmbedBuilder()
    .setTitle('📩 New Contact Message')
    .setColor(0x5b8fa8)
    .addFields(
      { name: '👤 Name',    value: name,    inline: true  },
      { name: '📧 Email',   value: email,   inline: true  },
      { name: '💬 Message', value: message, inline: false },
    )
    .setTimestamp()
    .setFooter({ text: 'DocShare TN — Contact Form' })] });
}

// ── sendReviewRequest ──────────────────────────────────────────
// Shows full document info + a direct preview link so moderators
// can inspect content before hitting Accept or Deny.
async function sendReviewRequest(doc) {
  if (!REVIEW_CHANNEL) return;
  try {
    const ch = await client.channels.fetch(REVIEW_CHANNEL);

    // File size formatted
    const sizeStr = doc.fileSize
      ? doc.fileSize > 1024 * 1024
        ? `${(doc.fileSize / 1024 / 1024).toFixed(1)} MB`
        : `${(doc.fileSize / 1024).toFixed(0)} KB`
      : 'Unknown';

    // Preview URL — direct link to the file for images/PDFs
    const previewUrl  = `${DOMAIN}${doc.filePath}`;
    const documentUrl = `${DOMAIN}/document/${doc.id}`;

    // Curriculum label
    const curriculumMap = {
      specific: '🔴 Specific (exclusive to this section)',
      shared:   '🟡 Shared (same programme for a subset)',
      common:   '🟢 Common (same programme for all)',
    };
    const curriculumLabel = curriculumMap[doc.curriculum] || doc.curriculum || 'Unknown';

    const embed = new EmbedBuilder()
      .setTitle('📄 New Document for Review')
      .setColor(0x5865f2)
      .setDescription(
        `**${doc.name}**\n` +
        `📎 [View File](${previewUrl}) • 📄 [Document Page](${documentUrl})`
      )
      .addFields(
        // Row 1 — identity
        { name: '🪪 ID',          value: `\`${doc.id}\``,          inline: true },
        { name: '📚 Type',        value: doc.docTypeLabel,          inline: true },
        { name: '🎓 Section',     value: doc.bacTypeLabel,          inline: true },
        // Row 2 — subject
        { name: '📖 Subject',     value: doc.subjectLabel,          inline: true },
        { name: '🔬 Curriculum',  value: curriculumLabel,           inline: false },
        // Row 3 — publisher
        { name: '👤 Publisher',   value: doc.publisherName,         inline: true },
        { name: '🎮 Discord ID',  value: doc.discordId ? `\`${doc.discordId}\`` : '—', inline: true },
        // Row 4 — file details
        { name: '📁 File',        value: doc.originalName,          inline: true },
        { name: '📏 Size',        value: sizeStr,                   inline: true },
        { name: '🗂️ MIME',       value: doc.mimetype || 'Unknown', inline: true },
        // Row 5 — timestamp
        { name: '🕐 Submitted',   value: new Date(doc.createdAt).toLocaleString('en-GB', {
            day:'2-digit', month:'short', year:'numeric',
            hour:'2-digit', minute:'2-digit'
          }), inline: false },
      )
      .setFooter({ text: 'DocShare TN — Pending moderation • Click the link above to preview the file' })
      .setTimestamp();

    // For images, embed thumbnail so moderator can see it inline
    const isImage = ['image/jpeg','image/png','image/gif','image/webp'].includes(doc.mimetype);
    if (isImage) embed.setImage(previewUrl);

    await ch.send({
      embeds: [embed],
      components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`accept__${doc.id}`).setLabel('✅ Accept').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(`deny__${doc.id}`).setLabel('❌ Deny').setStyle(ButtonStyle.Danger),
      )],
    });
  } catch (e) { console.error('[Bot] Review:', e.message); }
}

// ── logVisit ───────────────────────────────────────────────────
async function logVisit({ pageUrl, ip, referer, acceptLang, country, city, region, isp, device, browser, os }) {
  if (!LOG_CHANNEL) return;
  try {
    const ch = await client.channels.fetch(LOG_CHANNEL);

    const isLocal = ['127.0.0.1', 'Local'].includes(ip) ||
                    ip.startsWith('192.168.') ||
                    ip.startsWith('10.') ||
                    /^172\.(1[6-9]|2\d|3[01])\./.test(ip);

    // Build individual fields for max clarity
    const ipDisplay      = `\`${ip || 'Unknown'}\``;
    const countryDisplay = country || '—';
    const regionDisplay  = region  || '—';
    const cityDisplay    = city    || '—';
    const ispDisplay     = isp     || '—';
    const locationLine   = isLocal
      ? '🏠 Local / Dev server'
      : [city, region, country].filter(Boolean).join(', ') || '—';

    await ch.send({ embeds: [new EmbedBuilder()
      .setTitle('👁️ Page Visit')
      .setColor(0x4fc3d4)
      .addFields(
        { name: '🔗 URL',      value: pageUrl.slice(0, 1024),  inline: false },
        { name: '🌐 IP',       value: ipDisplay,               inline: true  },
        { name: '🏳️ Country',  value: countryDisplay,          inline: true  },
        { name: '🗺️ Region',   value: regionDisplay,           inline: true  },
        { name: '🏙️ City',     value: cityDisplay,             inline: true  },
        { name: '🏢 ISP',      value: ispDisplay,              inline: true  },
        { name: '📱 Device',   value: device  || 'Unknown',    inline: true  },
        { name: '🌍 Browser',  value: browser || 'Unknown',    inline: true  },
        { name: '💻 OS',       value: os      || 'Unknown',    inline: true  },
        { name: '🗣️ Lang',     value: acceptLang || '—',       inline: true  },
        { name: '📎 Referer',  value: (referer || 'Direct').slice(0, 256), inline: false },
      )
      .setTimestamp()
      .setFooter({ text: 'DocShare Analytics — data used only for moderation' })] });
  } catch { /* silent */ }
}

// ── logDownload ────────────────────────────────────────────────
async function logDownload(doc, { ip, device, browser, os, country, city, region, isp } = {}) {
  if (!LOG_CHANNEL) return;
  try {
    const ch = await client.channels.fetch(LOG_CHANNEL);
    const isLocal = ['127.0.0.1', 'Local'].includes(ip) ||
                    (ip || '').startsWith('192.168.') ||
                    (ip || '').startsWith('10.');
    const locationLine = isLocal
      ? '🏠 Local'
      : [city, region, country].filter(Boolean).join(', ') || '—';

    await ch.send({ embeds: [new EmbedBuilder()
      .setTitle('⬇️ Document Downloaded')
      .setColor(0x5b8fa8)
      .addFields(
        { name: '📄 Document',  value: `**${doc.name}** (\`${doc.id}\`)`, inline: false },
        { name: '🌐 IP',        value: `\`${ip || '?'}\``,  inline: true  },
        { name: '🏳️ Country',   value: country || '—',      inline: true  },
        { name: '🗺️ Location',  value: locationLine,         inline: true  },
        { name: '🏢 ISP',       value: isp     || '—',      inline: true  },
        { name: '📱 Device',    value: device  || 'Unknown', inline: true  },
        { name: '🌍 Browser',   value: browser || 'Unknown', inline: true  },
        { name: '💻 OS',        value: os      || 'Unknown', inline: true  },
        { name: '⬇️ DL #',      value: `${doc.downloads || 0}`, inline: true },
      )
      .setTimestamp()
      .setFooter({ text: 'DocShare Analytics' })] });
  } catch { /* silent */ }
}

function startBot() {
  if (!TOKEN || TOKEN === 'your_bot_token_here') {
    console.warn('[Bot] No token — Discord disabled.'); return;
  }
  client.login(TOKEN).catch(e => console.error('[Bot] Login:', e.message));
}

module.exports = { startBot, sendReviewRequest, sendContactMessage, logVisit, logDownload };
