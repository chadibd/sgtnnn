# 📚 DocShare — Plateforme de partage de documents scolaires

Plateforme EJS/Express.js complète avec :
- **Page 1** : Formulaire de soumission de documents (avec modération Discord)
- **Page 2** : Recherche et consultation de documents validés
- **Bot Discord** : boutons Accept/Deny, logs de visites/téléchargements, commande `/deletedoc`

---

## 🗂️ Structure du projet

```
docshare/
├── app.js                  # Serveur Express principal
├── bot.js                  # Bot Discord (discord.js v14)
├── .env                    # ← À configurer (voir ci-dessous)
├── .env.example            # Template
├── config/
│   ├── constants.js        # Matières, sections, types de documents
│   └── db.js               # Base de données JSON
├── data/
│   └── db.json             # Stockage persistant (créé automatiquement)
├── routes/
│   ├── upload.js           # POST/GET /upload — soumission
│   └── documents.js        # GET /search, /document/:id, /document/:id/download
├── views/
│   ├── upload.ejs          # Page 1 : Formulaire de soumission
│   ├── upload_success.ejs  # Confirmation après soumission
│   ├── search.ejs          # Page 2 : Recherche + filtres
│   ├── document.ejs        # Page document individuelle
│   ├── 404.ejs             # Page d'erreur
│   └── partials/
│       ├── header.ejs
│       └── footer.ejs
└── public/
    ├── css/style.css
    └── uploads/            # Fichiers uploadés (créé automatiquement)
```

---

## ⚙️ Installation

```bash
# 1. Installer les dépendances
npm install

# 2. Copier et configurer l'environnement
cp .env.example .env
# → Éditer .env avec vos valeurs (voir section Configuration)

# 3. Lancer le serveur
npm start
# Ou en mode dev (rechargement auto) :
npm run dev
```

---

## 🔧 Configuration — `.env`

```env
# ─── Bot Discord ────────────────────────────────────────────────────
DISCORD_BOT_TOKEN=votre_token_ici

# Salon où le bot envoie les demandes de validation (Accept/Deny)
REVIEW_CHANNEL_ID=ID_du_salon_de_modération

# Salon où le bot log les visites et téléchargements
LOG_CHANNEL_ID=ID_du_salon_de_logs

# ID du rôle qui peut utiliser /deletedoc
OWNER_ROLE_ID=ID_du_rôle_owner

# ─── Serveur ────────────────────────────────────────────────────────
PORT=3000
DOMAIN=https://votre-domaine.com
```

### Obtenir les IDs Discord

1. **Bot token** : [discord.com/developers](https://discord.com/developers/applications) → votre app → Bot
2. **Channel IDs** : Activer le mode développeur → clic droit sur le salon → "Copier l'identifiant"
3. **Role ID** : Paramètres du serveur → Rôles → clic droit → "Copier l'identifiant"

### Permissions du bot

Le bot a besoin des permissions suivantes :
- `Send Messages`
- `Embed Links`
- `Read Message History`
- `Use Application Commands` (pour `/deletedoc`)

**Intents requis** : `Guilds`, `Guild Messages`

---

## 🎮 Fonctionnement

### Soumission d'un document

1. L'utilisateur remplit le formulaire sur `/upload` :
   - Nom, ID Discord (validé comme Snowflake 17-19 chiffres)
   - Nom du document, type (Cours/Résumé/Exercices)
   - Section bac → les matières disponibles se chargent dynamiquement
   - Fichier (PDF, Word, PPT, Excel, Images, ZIP — max 50 Mo)

2. Le bot envoie un embed dans `REVIEW_CHANNEL_ID` avec deux boutons ✅ Accept / ❌ Deny

3. Le document n'est visible sur le site **que** si quelqu'un clique **Accept**

### Recherche

URL : `/search?q=texte&bacType=math&subject=mathematiques&docType=cours`

Chaque document publié est accessible via : `/document/DOC-XXXXXXXX`

### Commandes Discord

| Commande | Description | Rôle requis |
|---|---|---|
| `/deletedoc id:DOC-XXXX` | Supprime un document (fichier + base de données) | `OWNER_ROLE_ID` |

### Logs automatiques

Le bot envoie dans `LOG_CHANNEL_ID` :
- 👁️ Chaque visite sur une page document (URL + IP)
- ⬇️ Chaque téléchargement (ID doc, nom, auteur + IP)

---

## 🔒 Sécurité

- **Helmet.js** : headers HTTP sécurisés (CSP, X-Frame-Options, etc.)
- **Rate limiting** :
  - Global : 200 req/15min
  - Upload : 5 soumissions/heure par IP
  - Téléchargements : 30/10min par IP
- **Validation côté serveur** : express-validator sur tous les champs
- **Discord ID** : validation Snowflake (regex 17-19 chiffres)
- **Fichiers** : whitelist MIME types, limite 50 Mo, noms randomisés (UUID)
- **Chemin de fichier** : `path.basename()` pour éviter les traversals

---

## 🗃️ Base de données

Stockage JSON dans `data/db.json`. Structure d'un document :

```json
{
  "id": "DOC-A1B2C3D4",
  "name": "Cours de Maths — Fonctions",
  "publisherName": "Ahmed Benali",
  "discordId": "123456789012345678",
  "docType": "cours",
  "docTypeLabel": "Cours",
  "bacType": "math",
  "bacTypeLabel": "Bac Mathématiques",
  "subject": "mathematiques",
  "subjectLabel": "Mathématiques",
  "originalName": "maths_fonctions.pdf",
  "filePath": "/uploads/1234567-uuid.pdf",
  "fileSize": 204800,
  "mimetype": "application/pdf",
  "status": "pending|approved|denied",
  "createdAt": "2025-01-15T10:30:00.000Z",
  "reviewedBy": "Moderator#1234",
  "reviewedAt": "2025-01-15T12:00:00.000Z",
  "downloads": 47
}
```

---

## 📐 Sections et matières supportées

| Section | Valeur |
|---|---|
| Commun (tous) | `commun` |
| Bac Mathématiques | `math` |
| Bac Sciences Expérimentales | `sciences` |
| Bac Économie et Gestion | `eco` |
| Bac Technique | `technique` |
| Bac Lettres | `lettres` |
| Bac Sport | `sport` |
| Bac Informatique | `info` |

Les matières disponibles par section sont définies dans `config/constants.js` d'après les tableaux fournis.
