'use strict';

require('dotenv').config();

const express      = require('express');
const path         = require('path');
const helmet       = require('helmet');
const rateLimit    = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const { mkdirSync }= require('fs');

const { i18nMiddleware }                 = require('./config/i18n');
const { visitorMiddleware, recordVisit } = require('./config/visitorMiddleware');
const uploadRouter    = require('./routes/upload');
const documentsRouter = require('./routes/documents');
const bacRouter       = require('./routes/bac');
const contactRouter   = require('./routes/contact');
const bot             = require('./bot');

const app = express();

/* ── Security ─────────────────────────────────────────────────── */
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc:   ["'self'","'unsafe-inline'",'fonts.googleapis.com','cdn.jsdelivr.net'],
      fontSrc:    ["'self'",'fonts.gstatic.com','cdn.jsdelivr.net'],
      scriptSrc:  ["'self'","'unsafe-inline'"],
      imgSrc:     ["'self'",'data:','blob:'],
      frameSrc:   ["'self'"],
    },
  },
}));

/* ── Rate limit ────────────────────────────────────────────────── */
app.use(rateLimit({ windowMs:15*60*1000, max:300, standardHeaders:true, legacyHeaders:false }));

/* ── View engine ───────────────────────────────────────────────── */
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

/* ── Middleware ────────────────────────────────────────────────── */
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());
app.use(i18nMiddleware);
app.use(visitorMiddleware);

/* ── Static ────────────────────────────────────────────────────── */
app.use(express.static(path.join(__dirname, 'public')));
mkdirSync(path.join(__dirname, 'public', 'uploads'), { recursive: true });

/* ── App locals ────────────────────────────────────────────────── */
app.locals.DISCORD_INVITE = process.env.DISCORD_INVITE || 'https://discord.gg/';

/* ── Routes ────────────────────────────────────────────────────── */
app.get('/', (req, res) => {
  recordVisit(req);
  res.render('home', { title: 'Home', page: 'home' });
});

app.use('/upload',        uploadRouter);
app.use('/search',        documentsRouter);
app.use('/document',      documentsRouter);
// Section pages live at /bac/:section but are served by documentsRouter
app.use('/bac',           bacRouter);
app.use('/contact',       contactRouter);

/* ── 404 ───────────────────────────────────────────────────────── */
app.use((req, res) => res.status(404).render('404', { title:'Page not found', page:'' }));

/* ── Error ─────────────────────────────────────────────────────── */
app.use((err, req, res, _next) => {
  console.error(err.stack);
  res.status(500).render('404', { title:'Server error', page:'' });
});

/* ── Start ─────────────────────────────────────────────────────── */
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`[Server] http://localhost:${PORT}`));
bot.startBot();
module.exports = app;
