'use strict';

const express  = require('express');
const multer   = require('multer');
const path     = require('path');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const rateLimit = require('express-rate-limit');

const db = require('../config/db');
const {
  BAC_TYPES, SUBJECTS, getSubjectsForBac, getDocTypes
} = require('../config/constants');
const bot             = require('../bot');
const { recordVisit } = require('../config/visitorMiddleware');

const router = express.Router();

/* ── Rate limit ─────────────────────────────────────────────────── */
const uploadLimit = rateLimit({
  windowMs: 60 * 60 * 1000, max: 5,
  message: 'Too many uploads. Try again in an hour.',
  standardHeaders: true, legacyHeaders: false,
});

/* ── Multer ─────────────────────────────────────────────────────── */
const ALLOWED_MIME = [
  'application/pdf',
  'image/jpeg','image/png','image/gif','image/webp',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'text/plain','application/zip',
];

const storage = multer.diskStorage({
  destination: (req, file, cb) =>
    cb(null, path.join(__dirname, '..', 'public', 'uploads')),
  filename: (req, file, cb) =>
    cb(null, `${Date.now()}-${uuidv4()}${path.extname(file.originalname).toLowerCase()}`),
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (ALLOWED_MIME.includes(file.mimetype)) return cb(null, true);
    cb(new multer.MulterError('LIMIT_UNEXPECTED_FILE'));
  },
});

/* ── Discord ID validation (optional field) ─────────────────────── */
function isValidDiscordId(id) { return /^\d{17,19}$/.test(id); }

/* ── GET /upload ────────────────────────────────────────────────── */
router.get('/', (req, res) => {
  recordVisit(req);
  res.render('upload', {
    title: 'Share a Document',
    BAC_TYPES,
    DOC_TYPES: getDocTypes(res.locals.lang || 'en'),
    SUBJECTS,
    errors:   [],
    formData: {},
  });
});

/* ── AJAX: subjects for a given bac ────────────────────────────── */
router.get('/subjects/:bacType', (req, res) => {
  res.json(getSubjectsForBac(req.params.bacType));
});

/* ── POST /upload ───────────────────────────────────────────────── */
router.post('/',
  uploadLimit,
  (req, res, next) => {
    upload.single('document')(req, res, err => {
      if (err instanceof multer.MulterError) {
        req.fileError = err.code === 'LIMIT_FILE_SIZE'
          ? 'File must not exceed 50 MB.'
          : 'Unsupported file type.';
      } else if (err) {
        req.fileError = 'Upload error.';
      }
      next();
    });
  },

  /* Validation rules */
  body('publisherName').trim().notEmpty().withMessage('Name is required.')
    .isLength({ max: 80 }).withMessage('Name too long (max 80 chars).'),

  // Discord ID is OPTIONAL — validate only when provided
  body('discordId').trim().optional({ checkFalsy: true })
    .custom(val => {
      if (val && !isValidDiscordId(val))
        throw new Error('Invalid Discord ID (17-19 digits).');
      return true;
    }),

  body('docName').trim().notEmpty().withMessage('Document name is required.')
    .isLength({ max: 120 }).withMessage('Name too long (max 120 chars).'),

  body('docType').isIn(getDocTypes('en').map(d => d.value))
    .withMessage('Invalid document type.'),

  body('bacType').isIn(BAC_TYPES.map(b => b.value))
    .withMessage('Invalid bac section.'),

  body('subject').notEmpty().withMessage('Subject is required.')
    .custom((val, { req }) => {
      const allowed = getSubjectsForBac(req.body.bacType);
      if (!allowed.find(s => s.value === val))
        throw new Error('Invalid subject for this bac section.');
      return true;
    }),

  /* Process */
  async (req, res) => {
    const vErrors = validationResult(req);
    const errors  = [];

    if (req.fileError)                   errors.push(req.fileError);
    if (!req.file && !req.fileError)     errors.push('Please attach a file.');
    vErrors.array().forEach(e => errors.push(e.msg));

    if (errors.length) {
      if (req.file) { const fs = require('fs'); fs.unlink(req.file.path, () => {}); }
      return res.status(400).render('upload', {
        title: 'Share a Document',
        BAC_TYPES, DOC_TYPES: getDocTypes(res.locals.lang || 'en'), SUBJECTS,
        errors, formData: req.body,
      });
    }

    const docId      = 'DOC-' + uuidv4().split('-')[0].toUpperCase();
    const subjectObj = SUBJECTS.find(s => s.value === req.body.subject);
    const bacObj     = BAC_TYPES.find(b => b.value === req.body.bacType);
    const typeObj    = getDocTypes('en').find(d => d.value === req.body.docType);

    const doc = {
      id:            docId,
      name:          req.body.docName.trim(),
      publisherName: req.body.publisherName.trim(),
      discordId:     (req.body.discordId || '').trim() || null,
      docType:       req.body.docType,
      docTypeLabel:  typeObj?.label || req.body.docType,
      bacType:       req.body.bacType,
      bacTypeLabel:  bacObj?.label  || req.body.bacType,
      subject:       req.body.subject,
      subjectLabel:  subjectObj?.label || req.body.subject,
      subjectGroup:  subjectObj?.group || req.body.subject,
      curriculum:    subjectObj?.curriculum || 'specific',
      originalName:  req.file.originalname,
      filePath:      `/uploads/${req.file.filename}`,
      fileSize:      req.file.size,
      mimetype:      req.file.mimetype,
      status:        'pending',
      createdAt:     new Date().toISOString(),
      reviewedBy:    null,
      reviewedAt:    null,
      downloads:     0,
    };

    db.addDocument(doc);

    try { await bot.sendReviewRequest(doc); }
    catch (e) { console.error('[Upload] Discord:', e.message); }

    res.render('upload_success', { title: 'Document submitted', doc });
  }
);

module.exports = router;
