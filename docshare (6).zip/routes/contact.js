'use strict';

const express    = require('express');
const rateLimit  = require('express-rate-limit');
const { body, validationResult } = require('express-validator');
const bot        = require('../bot');

const router = express.Router();

const contactLimit = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  message: JSON.stringify({ ok: false, error: 'Too many messages. Try again in an hour.' }),
  standardHeaders: true,
  legacyHeaders: false,
});

router.post('/',
  contactLimit,
  body('name').trim().notEmpty().isLength({ max: 80 }),
  body('email').trim().isEmail().normalizeEmail(),
  body('message').trim().notEmpty().isLength({ max: 1000 }),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ ok: false, error: 'Invalid input.' });
    }
    const { name, email, message } = req.body;
    try {
      await bot.sendContactMessage({ name, email, message });
      res.json({ ok: true });
    } catch (e) {
      console.error('[Contact]', e.message);
      res.status(500).json({ ok: false, error: 'Could not send message.' });
    }
  }
);

module.exports = router;
