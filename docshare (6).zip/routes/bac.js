'use strict';

const express = require('express');
const db      = require('../config/db');
const { BAC_TYPES, getDocTypes, getSearchSubjectsForBac } = require('../config/constants');
const { recordVisit } = require('../config/visitorMiddleware');

const router = express.Router();

const VALID = ['math','sciences','eco','technique','lettres','sport','info'];

/* GET /bac/:section */
router.get('/:section', (req, res) => {
  const { section } = req.params;
  if (!VALID.includes(section)) {
    return res.status(404).render('404', { title: 'Section not found', page: '' });
  }

  recordVisit(req);
  const lang   = res.locals.lang || 'en';
  const bacObj = BAC_TYPES.find(b => b.value === section);
  const { q, subject, docType } = req.query;

  const docs = db.searchDocuments({ query: q, bacType: section, subject, docType });

  res.render('bac_section', {
    title:   bacObj.label,
    page:    'bac',
    bacObj,
    BAC_TYPES,
    DOC_TYPES: getDocTypes(lang),
    SUBJECTS:  getSearchSubjectsForBac(section),
    docs,
    filters: { q: q||'', subject: subject||'all', docType: docType||'all' },
  });
});

module.exports = router;
