'use strict';

const express   = require('express');
const path      = require('path');
const fs        = require('fs');
const rateLimit = require('express-rate-limit');

const db = require('../config/db');
const { BAC_TYPES, SUBJECTS, getDocTypes, getSearchSubjectsForBac } = require('../config/constants');
const { parseRequestAsync } = require('../config/useragent');
const { recordVisit }       = require('../config/visitorMiddleware');
const bot                   = require('../bot');

const router  = express.Router();
const dlLimit = rateLimit({ windowMs: 10*60*1000, max: 30 });

/* ── GET /search ────────────────────────────────────────────────── */
router.get('/', (req, res) => {
  recordVisit(req);
  const lang = res.locals.lang || 'en';
  const { q, bacType, subject, docType } = req.query;

  const subjects = getSearchSubjectsForBac(bacType && bacType !== 'all' ? bacType : null);

  // Pre-build subjects map for client-side dynamic update
  const subjectsByBac = { all: getSearchSubjectsForBac(null).map(s=>({value:s.value,label:s.label})) };
  ['math','sciences','eco','technique','lettres','sport','info'].forEach(bac => {
    subjectsByBac[bac] = getSearchSubjectsForBac(bac).map(s=>({value:s.value,label:s.label}));
  });

  const docs = db.searchDocuments({ query: q, bacType, subject, docType });

  res.render('search', {
    title: 'Search Documents',
    BAC_TYPES, SUBJECTS: subjects, DOC_TYPES: getDocTypes(lang),
    subjectsByBac, docs,
    filters: { q: q||'', bacType: bacType||'all', subject: subject||'all', docType: docType||'all' },
  });
});

/* ── GET /document/:id ──────────────────────────────────────────── */
router.get('/:id', (req, res) => {
  const doc = db.getDocument(req.params.id);
  if (!doc || doc.status !== 'approved') {
    return res.status(404).render('404', { title: 'Document not found', page: '' });
  }

  res.render('document', { title: doc.name, page: '', doc });

  const pageUrl = `${req.protocol}://${req.get('host')}${req.originalUrl}`;
  parseRequestAsync(req).then(info => {
    recordVisit(req);
    bot.logVisit({ pageUrl, ...info }).catch(() => {});
  }).catch(() => {});
});

/* ── GET /document/:id/download ─────────────────────────────────── */
router.get('/:id/download', dlLimit, (req, res) => {
  const doc = db.getDocument(req.params.id);
  if (!doc || doc.status !== 'approved') {
    return res.status(404).render('404', { title: 'Document not found', page: '' });
  }

  const filePath = path.join(__dirname, '..', 'public', 'uploads', path.basename(doc.filePath));
  if (!fs.existsSync(filePath)) {
    return res.status(404).render('404', { title: 'File not found', page: '' });
  }

  res.download(filePath, doc.originalName);
  db.recordDocDownload(doc.id);
  parseRequestAsync(req).then(info => {
    bot.logDownload(db.getDocument(doc.id), info).catch(() => {});
  }).catch(() => {});
});

module.exports = router;
